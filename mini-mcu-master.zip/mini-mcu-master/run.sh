#!/usr/bin/env bash

cd $(dirname $0)
./run -c    #编译汇编代码，并生成所需的文件  rom.v 机器指令  head.v 用于裁剪mcu的宏定义文件
./run       #运行仿真