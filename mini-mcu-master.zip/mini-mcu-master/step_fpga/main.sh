#!/bin/bash
./run.tcl
